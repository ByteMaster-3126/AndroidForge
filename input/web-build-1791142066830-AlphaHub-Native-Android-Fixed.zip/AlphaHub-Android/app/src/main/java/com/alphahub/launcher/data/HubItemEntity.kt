package com.alphahub.launcher.data

data class HubItem(
    val packageName: String,
    val label: String,
    val type: Type = Type.ANDROID
) {
    enum class Type { ANDROID, WEBSITE }
}
