package com.alphahub.launcher.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.alphahub.launcher.discovery.InstalledApp
import com.alphahub.launcher.discovery.InstalledAppDiscovery
import com.alphahub.launcher.launcher.AppLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

private val Black = Color(0xFF050505)
private val Gold = Color(0xFFD9A441)
private val GoldBright = Color(0xFFF3C969)
private val Card = Color(0xFF121212)

class MainActivity : ComponentActivity() {
    private lateinit var discovery: InstalledAppDiscovery
    private lateinit var launcher: AppLauncher
    private val prefs by lazy { getSharedPreferences("alpha_hub", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        discovery = InstalledAppDiscovery(this)
        launcher = AppLauncher(this)
        setContent { AlphaHubApp() }
    }

    private fun loadSaved(): Set<String> = prefs.getStringSet("android_packages", emptySet())?.toSet() ?: emptySet()
    private fun saveSaved(packages: Set<String>) { prefs.edit().putStringSet("android_packages", packages).apply() }

    @Composable
    private fun AlphaHubApp() {
        var apps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
        var savedPackages by remember { mutableStateOf(loadSaved()) }
        var showPicker by remember { mutableStateOf(false) }
        var query by rememberSaveable { mutableStateOf("") }
        var selectedTab by rememberSaveable { mutableIntStateOf(0) }
        var websiteUrl by rememberSaveable { mutableStateOf("") }
        var websites by rememberSaveable { mutableStateOf(listOf<String>()) }

        fun refresh() {
            lifecycleScope.launch {
                apps = discovery.getLaunchableApps()
                val installed = apps.map { it.packageName }.toSet()
                val valid = savedPackages.intersect(installed)
                if (valid != savedPackages) {
                    savedPackages = valid
                    saveSaved(valid)
                }
            }
        }

        LaunchedEffect(Unit) { refresh() }

        MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = GoldBright, background = Black, surface = Card)) {
            Scaffold(
                containerColor = Black,
                topBar = {
                    Column(Modifier.background(Black).padding(horizontal = 18.dp, vertical = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                bitmap = loadLogo().asImageBitmap(),
                                contentDescription = "Alpha Imperium",
                                modifier = Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("ALPHA HUB", color = GoldBright, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text("ALPHA IMPERIUM", color = Gold, style = MaterialTheme.typography.labelMedium, letterSpacing = 2.sp)
                            }
                            Icon(Icons.Default.Settings, null, tint = Gold)
                        }
                        Spacer(Modifier.height(12.dp))
                        TabRow(selectedTabIndex = selectedTab, containerColor = Color.Transparent, contentColor = GoldBright) {
                            Tab(selectedTab == 0, { selectedTab = 0 }, text = { Text("Installed Apps") }, icon = { Icon(Icons.Default.Smartphone, null) })
                            Tab(selectedTab == 1, { selectedTab = 1 }, text = { Text("Websites") }, icon = { Icon(Icons.Default.Language, null) })
                        }
                    }
                }
            ) { padding ->
                if (selectedTab == 0) {
                    InstalledScreen(
                        modifier = Modifier.padding(padding),
                        apps = apps,
                        savedPackages = savedPackages,
                        query = query,
                        onQuery = { query = it },
                        onAdd = { showPicker = true },
                        onLaunch = { launcher.launchInstalledApp(it) },
                        onRemove = {
                            savedPackages = savedPackages - it
                            saveSaved(savedPackages)
                        }
                    )
                } else {
                    WebsiteScreen(
                        modifier = Modifier.padding(padding),
                        url = websiteUrl,
                        onUrl = { websiteUrl = it },
                        websites = websites,
                        onAdd = {
                            if (websiteUrl.isNotBlank()) {
                                websites = (websites + websiteUrl.trim()).distinct()
                                websiteUrl = ""
                            }
                        },
                        onOpen = { launcher.launchWebsite(it) },
                        onRemove = { websites = websites - it }
                    )
                }
            }
        }

        if (showPicker) {
            AppPickerDialog(
                apps = apps,
                initiallySelected = savedPackages,
                onDismiss = { showPicker = false },
                onConfirm = { selected ->
                    savedPackages = selected
                    saveSaved(selected)
                    showPicker = false
                }
            )
        }
    }

    @Composable
    private fun InstalledScreen(
        modifier: Modifier,
        apps: List<InstalledApp>,
        savedPackages: Set<String>,
        query: String,
        onQuery: (String) -> Unit,
        onAdd: () -> Unit,
        onLaunch: (String) -> Unit,
        onRemove: (String) -> Unit
    ) {
        val saved = apps.filter { it.packageName in savedPackages }
        Column(modifier.fillMaxSize().padding(16.dp)) {
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("ADD ANDROID APP", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text("Search installed apps") })
            Spacer(Modifier.height(18.dp))
            Text("MY APPS", color = GoldBright, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (saved.isEmpty()) {
                EmptyCard("No Android apps added yet.\nTap ADD ANDROID APP to choose real apps installed on this phone.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(saved, key = { it.packageName }) { app -> AppRow(app, onLaunch, onRemove) }
                }
            }
        }
    }

    @Composable
    private fun AppPickerDialog(apps: List<InstalledApp>, initiallySelected: Set<String>, onDismiss: () -> Unit, onConfirm: (Set<String>) -> Unit) {
        var selected by remember { mutableStateOf(initiallySelected.toMutableSet()) }
        var search by rememberSaveable { mutableStateOf("") }
        val filtered = apps.filter { it.label.contains(search, true) || it.packageName.contains(search, true) }
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Card,
            title = { Text("ADD ANDROID APP", color = GoldBright, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text("Search installed apps...") })
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { selected = apps.map { it.packageName }.toMutableSet() }) { Text("SELECT ALL", color = GoldBright) }
                        TextButton(onClick = { selected = mutableSetOf() }) { Text("CLEAR", color = GoldBright) }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(filtered, key = { it.packageName }) { app ->
                            Row(Modifier.fillMaxWidth().clickable { selected = selected.toMutableSet().also { set -> if (!set.add(app.packageName)) set.remove(app.packageName) } }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                AppIcon(app.icon, Modifier.size(42.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(app.label, color = Color.White); Text(app.packageName, color = Color.Gray, style = MaterialTheme.typography.labelSmall) }; Checkbox(selected.contains(app.packageName), { checked -> selected = selected.toMutableSet().also { set -> if (checked) set.add(app.packageName) else set.remove(app.packageName) } }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                            }
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { onConfirm(selected) }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text("ADD SELECTED") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL", color = GoldBright) } }
        )
    }

    @Composable
    private fun AppRow(app: InstalledApp, onLaunch: (String) -> Unit, onRemove: (String) -> Unit) {
        Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(app.icon, Modifier.size(52.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(app.label, color = Color.White, fontWeight = FontWeight.SemiBold); Text(app.packageName, color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
                TextButton(onClick = { onLaunch(app.packageName) }) { Text("OPEN", color = GoldBright) }
                IconButton(onClick = { onRemove(app.packageName) }) { Icon(Icons.Default.Delete, "Remove", tint = GoldBright) }
            }
        }
    }

    @Composable
    private fun WebsiteScreen(modifier: Modifier, url: String, onUrl: (String) -> Unit, websites: List<String>, onAdd: () -> Unit, onOpen: (String) -> Unit, onRemove: (String) -> Unit) {
        Column(modifier.fillMaxSize().padding(16.dp)) {
            Text("WEBSITE / WEB APP", color = GoldBright, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(url, onUrl, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Website URL") }, placeholder = { Text("https://example.com") })
            Spacer(Modifier.height(8.dp))
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("ADD WEBSITE") }
            Spacer(Modifier.height(18.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(websites) { site -> Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Language, null, tint = GoldBright); Spacer(Modifier.width(10.dp)); Text(site, color = Color.White, modifier = Modifier.weight(1f)); TextButton(onClick = { onOpen(site) }) { Text("OPEN", color = GoldBright) }; IconButton(onClick = { onRemove(site) }) { Icon(Icons.Default.Delete, null, tint = GoldBright) } } } } }
        }
    }

    @Composable private fun EmptyCard(text: String) { Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) { Text(text, color = Color.LightGray, modifier = Modifier.padding(18.dp)) } }

    @Composable private fun AppIcon(icon: Drawable?, modifier: Modifier) {
        val bitmap = remember(icon) { drawableToBitmap(icon) }
        if (bitmap != null) Image(bitmap.asImageBitmap(), null, modifier = modifier.clip(RoundedCornerShape(12.dp))) else Box(modifier.background(Gold.copy(alpha = .2f), RoundedCornerShape(12.dp)))
    }

    private fun drawableToBitmap(drawable: Drawable?): Bitmap? {
        if (drawable == null) return null
        val w = maxOf(1, drawable.intrinsicWidth)
        val h = maxOf(1, drawable.intrinsicHeight)
        val bitmap = Bitmap.createBitmap(w.coerceAtMost(192), h.coerceAtMost(192), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun loadLogo(): Bitmap = android.graphics.BitmapFactory.decodeResource(resources, com.alphahub.launcher.R.drawable.alpha_imperium_logo)
}
