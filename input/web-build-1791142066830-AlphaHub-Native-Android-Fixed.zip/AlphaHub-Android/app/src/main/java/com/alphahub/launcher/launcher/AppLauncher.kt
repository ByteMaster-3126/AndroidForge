package com.alphahub.launcher.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

class AppLauncher(private val context: Context) {
    fun launchInstalledApp(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: run {
                Toast.makeText(context, "App is no longer installed or has no launcher", Toast.LENGTH_SHORT).show()
                return false
            }
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "Unable to launch this application", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun launchWebsite(url: String): Boolean {
        val clean = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(clean)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (_: Exception) {
            Toast.makeText(context, "No browser available", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
