# Alpha Hub — fixed native Android project

This version fixes the Installed Apps feature by using the Android PackageManager directly. It does **not** use website URLs to represent installed Android applications.

## Installed Android apps
- Discovers launchable applications dynamically from the device.
- Shows real application names, package names and icons.
- Search by name/package.
- Multi-select and add to Alpha Hub.
- Saves package names locally.
- Launches the real installed app with its Android launch intent.
- Removes only the Alpha Hub entry; it never uninstalls the real app.
- Revalidates saved packages when the app starts.

## Website/Web App support
Website shortcuts remain a separate section and continue to use URLs.

## Branding
Uses the supplied Alpha Imperium logo as the application branding/launcher source.

## Build
Open the `AlphaHub-Android` directory in Android Studio and run `app` on an Android device/emulator. Build `app-debug.apk` or a signed release APK from Android Studio.
